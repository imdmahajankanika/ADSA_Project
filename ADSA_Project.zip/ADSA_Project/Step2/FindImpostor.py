# Step 2

"""
Return the pairs of suspected impostors in the game.

"""
# A graph is a list of adjacency lists for each node in the graph.
# Adjacency matrix to represent the relationship between the players(whether one player has seen the other) after the first kill report
graph = [
            [0, 1, 0, 0, 1, 1, 0, 0, 0, 0],
            [1, 0, 1, 0, 0, 0, 1, 0, 0, 0],
            [0, 1, 0, 1, 0, 0, 0, 1, 0, 0],
            [0, 0, 1, 0, 1, 0, 0, 0, 1, 0],
            [1, 0, 0, 1, 0, 0, 0, 0, 0, 1],
            [1, 0, 0, 0, 0, 0, 0, 1, 1, 0],
            [0, 1, 0, 0, 0, 0, 0, 0, 1, 1],
            [0, 0, 1, 0, 0, 1, 0, 0, 0, 1],
            [0, 0, 0, 1, 0, 1, 0, 0, 0, 1],
            [0, 0, 0, 0, 1, 0, 1, 1, 0, 0]
        ]
Ver = len(graph) # Count of vertices will be equal to number of players (0-9) in represented as nodes of the graph

# Get the neighbours of the suspected impostors, so that we can find out the set of players who have not seen 1, 4 or 5  
def get_adjacent_nodes(graph,node):
        """
        For a given node, return a list of all the other nodes it's connected to.
        """
        list_of_neighbours = []
        for i in range(Ver):
            if graph[node][i]==1:
                list_of_neighbours.append(str(i))
        return set(list_of_neighbours)


def suspected_impostors_set(graph):
    players = set([str(i) for i in range(10)]) # We have no. of players from (0-9)
    """
    Player 0 has been reported dead. So, 1, 4 and 5 may be an impostor. 
    Considering the second impostor hasn’t seen player 1, 4 or 5, define a set of probable impostors.
    """
    
    for i in [1, 4, 5]:
        nodes=get_adjacent_nodes(graph, i)
        print(f"\nNeighboring nodes of '{i}'... \n")
        print("'{}' : {}\n".format(i,nodes))
        imposters= players - nodes - {str(i)}
        print(f"Impostors associated with '{i}'...\n")
        for imp in imposters:
            print(f"({i},{imp})",end=" ")
        print("\n\n***********************************\n")

if __name__=="__main__":
    # Adjacency_matrix: Matrix of players that have seen each other.
    print("\nAdjacency_matrix: Matrix of players that have seen each other...\n")
    print(graph)
    print("\n*********************************************************************")
    suspected_impostors_set(graph)
  