# Step 1
import random as rnd
from statistics import mean
from operator import attrgetter
from Player import Player
from Database import AVL
import os
class Game:
    """
    Implementation of the Game for the step 1
    players : list of players for this game (10)
    impostors : list of players who are impostors (2)
    """
    def __init__(self):
        print("\nWelcome to the Zerator's 'Among Us' tournament for the next ZLAN! \n\n")
        # Get the names of the players from list_of_players file
        playerNames = get_playerNames()
        self.players = [Player(p) for p in playerNames]
        self.update_ranking()
                

    def update_ranking(self):
        # All players are initially inserted in the database with a score=0
        datastr = AVL()
        for p in self.players:
            datastr.insert(p)
        self.ranking = datastr
        return self.ranking

    def __repr__(self):
        datastr = AVL()
        res = ""
        for player in datastr.inorder(self.ranking.root):
            res += f"{repr(player)}\n"
        print(res)
        return res

    def generate_random_score(self, players:list):
        '''
        Method to generate and assign random scores to the 10 players
    
        '''
        # Shuffle the order of players in the group randomly
        rnd.shuffle(players)
        (impostor1, impostor2) = players[:2] # Select two players as impostors
        crewmates = players[2:] # Select rest of the players as crewmates
        impostor1.role = True
        impostor2.role = True
        for p in crewmates:
            p.role = False
        temp = rnd.randint(1, 100)
        if temp > 30:
            # Crewmates win
            # Calculate Impostors' points
            temp = rnd.randint(0, 6)
            temp2 = rnd.randint(temp, 6)
            impostor1.score += temp
            impostor2.score += temp2 - temp
            # Maximum two undiscovered murders
            temp = rnd.randint(0, min(2, temp2))
            killers = rnd.choices([impostor1, impostor2], k=temp)
            for k in killers:
                k.score += 3
            # Calculate Crewmates' points
            temp = rnd.randint(1, 100)
            if temp > 80:
                # There are chances to win the task if all crewmates get 6 pts
                for c in crewmates:
                    c.score += 6
                temp = rnd.randint(1, 100)
                if temp > 30:
                    p = rnd.choice(crewmates) # There are 70% chances that one of the impostors is unmasked by p
                    p.score += 3 # 3pts if the argument unmasks an imposter
                    
            else:
                #  5pts if crewmate wins
                for c in crewmates:
                    c.score += 5
                # 3pts if the crewmate unmasks an impostor and there can be two impostors
                (c1, c2) = rnd.choices(crewmates, k=2)
                c1.score += 3
                c2.score += 3
                # 1pts if all solo tasks are made
                task_points = rnd.randint(0, 7)
                task_performers = rnd.sample(crewmates, task_points)
                for c in task_performers:
                    c.score += 1
        else:
            # Crewmates' pts
            task_points = rnd.randint(0, 7)
            task_performers = rnd.sample(crewmates, task_points)
            for c in task_performers:
                c.score += 1
            # Impostor win:10 pts
            impostor1.score += 10
            impostor2.score += 10
            temp = rnd.randint(1, 100)
            if temp > 50:
                # If all 8 crewmates are killed
                temp = rnd.randint(0, 8)
                impostor1.score += temp
                impostor2.score += 8 - temp
                # Crewmates' unmask pts
                c = rnd.choice(crewmates)
                c.score += 3
                # Probability of undiscovered murders
                temp = rnd.randint(1, 100)
                if temp <= 20:
                    # 2 undiscovered murders
                    killers = rnd.choices([impostor1, impostor2], k=2)
                    for k in killers:
                        k.score += 3
                elif temp <= 80:
                    # 1 undiscovered murder
                    killer = rnd.choice([impostor1, impostor2])
                    killer.score += 3
            else:
                # Both wins: 6 kills in total
                temp = rnd.randint(0, 6)
                impostor1.score += temp
                impostor2.score += 6 - temp
                # Probability of undiscovered murders
                temp = rnd.randint(1, 100)
                if temp <= 20:
                    # 2 undiscovered murders
                    killers = rnd.choices([impostor1, impostor2], k=2)
                    for k in killers:
                        k.score += 3
                elif temp <= 80:
                    # 1 undiscovered murders
                    killer = rnd.choice([impostor1, impostor2])
                    killer.score += 3   


    def drop_last_players(self):
        """
        Delete the 10 last players from the game based on their ranking in the tournament

        """
        
        for _ in range(10):
            """ The players are stored in a structured database with a log complexity to reach an element which
                corresponds to a score. So, get min score in log(n)
            """
            root = self.ranking.root
            while root.left:
                root = root.left
            self.ranking.delete(root.score)


    def game_rounds(self):
        ''' Each round consist of 3 consecutive games in which each players has to stack as much points as possible following the ranking model
            At the end of each round, players are attributed a score which is the mean of the points they have obtained during the last 3 games.
        '''
        datastr= AVL()
        players = datastr.inorder(self.ranking.root)
        # Play 3 random games, then each game regroups the players by a batch of ten following their ranking
        print("********************************************************")
        for i in range(3):
            print("Playing random game {} out of 3...".format(i+1))
            # shuffle the order of players randomly
            rnd.shuffle(players)
            # List of all the random groups.
            groups = [players[i:i + 10] for i in range(1, 92, 10)]
            for group in groups:
                self.generate_random_score(group)
        self.players = datastr.inorder(self.ranking.root)
        self.update_ranking()
        print()
        print("********************************************************")

        # Now, play the 9 ranking rounds until it remains only 10 players
        print("Now, play the 9 ranking rounds until it remains only 10 players\n")
        for i in range(9):
            print("Playing ranked game {} out of 9...".format(i+1))
            groups = [self.players[i:i + 10] for i in range(1, len(self.players) + 1, 10)]
            for group in groups:
                self.generate_random_score(group)
            self.drop_last_players()
        print("********************************************************")

    def finals(self):
        # Update and check the ranking of the last 10 players before last 5 games
        datastr= AVL()
        self.players = datastr.inorder(self.ranking.root)
        print("\nFinal 10 players based on rankings:- \n")
        for i in range(10):
            print(f"{repr(self.players[i])}")
        print()
        print("********************************************************")

        # Reset scores to 0
        print("Resetting scores and roles...\n")
        
        for p in self.players:
            p.score = 0
            p.role=False
        for i in range(10):
            print(f"{repr(self.players[i])}")
        print()
        print("********************************************************")
        final_players = self.players
        print("Finals...\n")
        for i in range(5):
            print("Playing final game {} out of 5...".format(i+1))
            rnd.shuffle(final_players)
            self.generate_random_score(final_players)
        self.update_ranking()
        self.players = datastr.inorder(self.ranking.root)
        scoreboard = [f"Rank {i + 1}: {repr(p)}" for i, p in enumerate(self.players[::-1])]
        print()
        print("********************************************************")
        print("\n\nFinal Scoreboard:-\n__________________________________\n*",'\n* '.join(scoreboard))


def get_playerNames():
    with open("list_of_players.txt", 'r') as f:
        line = f.readlines()
    return [i.strip() for i in line]

if __name__ == "__main__":
    game = Game()
    game.game_rounds()
    game.finals()