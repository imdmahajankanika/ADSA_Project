# Step 3
import math
import numpy as np
import sys
import copy
import pandas as pd

class floyd_warshall:
    """
    Compute Floyd-Warshall's algorithm from all sources taking an adjacency matrix as input
    
    """
    def __init__(self, graph, file):
        f = open(file,"r+")
        f.truncate(0)
        f.close()
        self.inf = sys.maxsize
        self.V = len(graph)
        self.const_matrix(graph)

    def const_matrix(self, graph):
        self.graph = graph
        for i in range(self.V):
            for j in range(self.V):
                if graph[i][j] == 0:
                   self.graph[i][j] = self.inf
                else:
                      self.graph[i][j]= graph[i][j]

    def floyd_warshall_algo(self, file):
        self.dist = list(map(lambda x : list(map(lambda y : y, x)), self.graph))
        for k in range(self.V):
            for x in range(self.V):
                for y in range(self.V):
                    if self.dist[x][y] >  self.dist[x][k] + self.dist[k][y]:
                        self.dist[x][y]=self.dist[x][k] + self.dist[k][y]
            self.display(file)
 
    def display(self, file):
        tmp = copy.deepcopy(self.dist)
        for x in range(len(tmp)):
            for y in range(len(tmp)):
                if x != y:
                    if tmp[x][y] == sys.maxsize:
                        tmp[x][y] = math.inf
                    else:
                        tmp[x][y]=tmp[x][y]
                else:
                    tmp[x][y] = 0
        with open(file, "w") as f:
            for i in range(len(tmp)):
                f.write(str(i + 1) + "\t" + str(tmp[i]) + "\n")
            f.close()

# Adjacency matrix (14x14) representing the crewmates
Crew =  [[0, 2, 2, 1, 2, 0, 0, 0, 0, 0, 0, 0, 0, 4],
        [2, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [2, 2, 0, 0, 0, 0, 0, 3, 3, 3, 6, 0, 0, 0],
        [1, 0, 0, 0, 0, 2, 5, 7, 0, 0, 0, 0, 0, 0],
        [2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4],
        [0, 0, 0, 2, 0, 0, 5, 7, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 5, 0, 5, 0, 6, 0, 0, 0, 0, 0, 0],
        [0, 0, 3, 7, 0, 7, 6, 0, 2, 0, 0, 0, 0, 0],
        [0, 0, 3, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0],
        [0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 5, 0, 0, 0],
        [0, 0, 6, 0, 0, 0, 0, 0, 0, 5, 0, 3, 3, 5],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 2, 3],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 2, 0, 3],
        [4, 0, 0, 0, 4, 0, 0, 0, 0, 0, 5, 3, 3, 0]]

# Adjacency matrix  representing impostors
Imp =   [[0, 0, 2, 1, 2, 4, 4, 2, 0, 0, 0, 0, 0, 4],
        [0, 0, 2, 4, 0, 4, 4, 2, 0, 0, 0, 0, 0, 0],
        [2, 2, 0, 0, 0, 0, 0, 3, 3, 3, 6, 0, 0, 0],
        [1, 4, 0, 0, 0, 2, 0, 7, 0, 0, 0, 0, 0, 0],
        [2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4],
        [4, 4, 0, 2, 0, 0, 5, 7, 0, 0, 0, 0, 0, 0],
        [4, 4, 0, 0, 0, 5, 0, 0, 0, 0, 0, 0, 0, 0],
        [2, 2, 3, 7, 0, 7, 0, 0, 2, 0, 0, 0, 0, 0],
        [0, 0, 3, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0],
        [0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 5, 0, 0, 0],
        [0, 0, 6, 0, 0, 0, 0, 0, 0, 5, 0, 3, 0, 5],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 2, 3],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0],
        [4, 0, 0, 0, 4, 0, 0, 0, 0, 0, 5, 3, 0, 0]]

if __name__=="__main__":
    file_crew= "crewmates.txt"
    file_imp= "Impostor.txt"
    alg_crew = floyd_warshall(Crew, file_crew)
    alg_crew.floyd_warshall_algo(file_crew)
    print("\nDistance matrix of the rooms for crewmates....")
    f=open(file_crew)
    print(f.read())
    f.close()
    print("******************************************************************************")
    print("\nDistance matrix of the rooms for impostors...")
    f=open(file_imp)
    print(f.read())
    f.close()
    alg_imp = floyd_warshall(Imp, file_imp)
    alg_imp.floyd_warshall_algo(file_imp)
    