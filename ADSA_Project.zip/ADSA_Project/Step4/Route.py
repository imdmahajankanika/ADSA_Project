# Step 4
import numpy as np
import math

class Graph:
    def __init__(self):
        pass
    
    def get_nodes(self,nodes: str):
        '''
        Get the node, its neighbour and the distance between them from graph file
        '''
        n = nodes.split()
        return int(n[0]), int(n[1]), int(n[2])

    def graph(self,path: str):
        '''
        Load the graph from Graph.txt containing neigbouring nodes and the distance between them
        '''
        with open(path) as f:
            node_list = list(map(str.strip, f.readlines()))
        edges = [(i, j) for i, j, _ in map(self.get_nodes, node_list)]
        
        size = np.max(edges)
        adj_matrix=[[math.inf for _ in range(size)] for _ in range(size)]

        for i, j, k in list(map(self.get_nodes, node_list)):
            adj_matrix[i - 1][j - 1] = k
            adj_matrix[j - 1][i - 1] = k
        
        adj_list = [[] for _ in range(size)]
        
        for i, j in edges:
            adj_list[i - 1].append(j - 1)
            adj_list[j - 1].append(i - 1)

        return adj_list, adj_matrix, size

def hamiltonian(g, size):
    """
    Using backtracking algorithm so as to find hamiltonian paths in a graph.
    """
    paths = []
    def _hamiltonian(g, i, trvrsd, path, size):
        if len(path) == size:
            paths.append(path[:])

        for x in g[i]:
            if not trvrsd[x]:
                trvrsd[x] = True
                path.append(x)

                _hamiltonian(g, x, trvrsd, path, size)

                trvrsd[x] = False
                path.pop()

    for i in range(size):
        trvrsd = [False for _ in range(size)]
        trvrsd[i] = True
        path = [i]
        _hamiltonian(g, i, trvrsd, path, size)

    return paths

def shortest_dist_path(paths, adj_matrix):
    # calculate the hamiltonian path with shortest distance
    least_dist = math.inf
    path = []
    for p in paths:
        dist = 0
        for i in range(len(p) - 1):
            dist=dist+adj_matrix[p[i]][p[i + 1]]
        if dist < least_dist and dist:
            least_dist = dist
            path = p

    return least_dist,path

if __name__=="__main__":
    gr=Graph()
    g, adj_matrix,size = gr.graph(f"Graph.txt")
    paths = hamiltonian(g,size)
    shortest_dist, path = shortest_dist_path(paths,adj_matrix)
    # Indexing from 1-14, as graph is indexed at 1
    x=list(map(lambda i: i+1, path))
    print(f"\nShortest route with distance '{shortest_dist}' to pass through each room only one time:-")
    print(x)







    
    