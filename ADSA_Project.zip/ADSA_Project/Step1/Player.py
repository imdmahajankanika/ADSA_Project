#Player implementation for the step 1.
class Player:
    
    """
    Player representation with its name,its score,role, height and right/left subtrees.
    Also points to potential neighbour nodes.
    """
    def __init__(self, name, score=0, role=False):
        self.name = name
        self.score = score
        self.role = role
        self.left = None
        self.right = None
        self.parent = None
        self.height = 1

    def __str__(self):
        return str(self.name)

    def __repr__(self):
        if self.role:
            role = "Imposter"
        else:
            role = "Crewmate"
        return "{}({}): {} ".format(self.name,role,self.score)
