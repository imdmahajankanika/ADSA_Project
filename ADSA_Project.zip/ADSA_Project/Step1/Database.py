from Player import Player

class AVL:
    ''' 
    An AVL tree used to represent a tournament, with each node considered as a player.

    '''
    def __init__(self, player=None):
        self.root = player

    def insert(self, key: Player):
        self.root = self._insert(self.root, key, key.score)

    def _insert(self, root: Player, key: Player, val: int):
        if not root:
            return Player(key.name, val, role=key.role)
        elif key.score < root.score:
            root.left = self._insert(root.left, key, key.score)
        else:
            root.right = self._insert(root.right, key, key.score)

        root.height = 1 + max(self._getHeights(root.left),
                              self._getHeights(root.right))

        bal = self.getBalance(root)

        # Case 1 :- Left-Left rotation
        if bal > 1 and key.score <= root.left.score:
            return self.rotate_right(root)

        # Case 2 :- Right-Right rotation
        if bal < -1 and key.score >= root.right.score:
            return self.rotate_left(root)

        # Case 3 :- Left-Right rotation
        if bal > 1 and key.score > root.left.score:
            root.left = self.rotate_left(root.left)
            return self.rotate_right(root)

        # Case 4 :- Right-Left rotation
        if bal < -1 and key.score < root.right.score:
            root.right = self.rotate_right(root.right)
            return self.rotate_left(root)

        return root
    
    def rotate_right(self, p: Player):
        """
        Right rotation
        set self as the right subtree of the left subtree
        """
        x = p.left
        temp = x.right
        x.right = p
        p.left = temp

        p.height = 1 + max(self._getHeights(p.left), self._getHeights(p.right))
        x.height = 1 + max(self._getHeights(x.left), self._getHeights(x.right))

        return x

    def rotate_left(self, p):
        """
        Left rotation
        set self as the left subtree of right subree
        """
        x = p.right
        temp = x.left
        x.left = p
        p.right = temp

        p.height = 1 + max(self._getHeights(p.right), self._getHeights(p.left))
        x.height = 1 + max(self._getHeights(x.right), self._getHeights(x.left))

        return x

    def delete(self, key):
        self.root = self._delete(self.root, key)

    def _delete(self, root, key):
        if not root:
            return root

        if key < root.score:
            root.left = self._delete(root.left, key)

        else:
            if root.left is None:
                temp = root.right
                root = None
                return temp

            elif root.right is None:
                temp = root.left
                root = None
                return temp

            temp = self.get_min_node(root.right)
            root.score = temp.score
            root.right = self._delete(root.right, temp.score)

        if root is None:
            return root
        """
         Tree height is max height of either left or right subtrees +1 for root of the tree
        """
        root.height = 1 + max(self._getHeights(root.left),
                                self._getHeights(root.right))

        # Rebalance tree 
        """
        After inserting or deleting a node,it is required to check each of the node's ancestors to make sure that AVL tree is balanced
        
        """                      
        bal = self.getBalance(root)

        if bal> 1 and self.getBalance(root.left) >= 0:
            return self.rotate_right(root)

        if bal < -1 and self.getBalance(root.right) <= 0:
            return self.rotate_left(root)

        if bal > 1 and self.getBalance(root.left) < 0:
            root.left = self.rotate_left(root.left)
            return self.rotate_right(root)

        if bal < -1 and self.getBalance(root.right) < 0:
            root.right = self.rotate_right(root.right)
            return self.rotate_left(root)

        return root

    def _getHeights(self, root: Player):
       
        if not root:
            return 0
        else:
            return root.height

    def get_min_node(self, root):
        if root is None or root.left is None:
            return root
        return self.get_min_node(root.left)

    def getBalance(self, root):
        """
        Calculate balance factor of the  AVL tree
        The balance factor is calculated using below formula:-
        balance = height(left subtree) - height(right subtree). 
        """
        if not root:
            return 0
        return self._getHeights(root.left) - self._getHeights(root.right)

    def inorder(self,root):
    # Returns a list of Player, sorted by their score in ascending order.
    # Left -> Root -> Right
        res = []
        if root:
            res = self.inorder(root.left)
            res.append(root)
            res = res + self.inorder(root.right)
        return res

